/* Implement your test code here. DO NOT remove function signatures below. You may add other functions as needed. */
#include "surfers.h" /* has dataT, NSURFERS */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

void surf(dataT *d) {
    /* ... */
    printf("surfer %d is surfing now\n", d->id);
fflush(stdout);
    d->state = SURFING;
    sleep(rand()%5);
     }

void leave(dataT *d) {
    /* ... */
    printf("surfer %d leaves..surfing done\n", d->id);
fflush(stdout);
    d->state = LEAVE;
    
}

void getReady(dataT *d) {
    /* ... */
    printf("surfer %d arrives for surfing \n", d->id);
fflush(stdout);
    d->state = READY;
    
}

void monitor(void * x) 
{
	sleep(1);	
	sem_post(&dusk);
	printf("DUSK\n");
	

}

