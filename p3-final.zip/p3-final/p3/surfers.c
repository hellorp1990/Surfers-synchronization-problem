/* DO NOT remove includes */
#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <semaphore.h>
#include "surfers.h"

#define handle_error_en(en, msg) \
               do { errno = en; perror(msg); exit(EXIT_FAILURE); } while (0)

  sem_t mutex;
  sem_t ComingToSurf;
  sem_t GoingToLeave;
  int numOfsurfing = 0; int ReadyForSurfing =0; int ReadyForLeaving=0;
  pthread_t t[NSURFERS];
/* ... */


/* Declare synchronization variables */
/* ... */

/* Add code to surfer's thread. Surfer MUST call getReady, surf, and leave (in that order) */
void surfer(void *dptr) 
{
  dataT *d = (dataT *)dptr;
  getReady(d);
  sem_wait(&mutex);
  ReadyForSurfing++;

//entering conditions
if (numOfsurfing == 0 )

  {
      if(ReadyForSurfing == 1)
{
      sem_post(&mutex);
      sem_wait(&ComingToSurf);
  }

  else if (ReadyForSurfing == 2)
  {
      sem_post(&ComingToSurf);
      ReadyForSurfing-=2;
      numOfsurfing+=2;
      sem_post(&mutex);
  }}
  else
  {
      if(numOfsurfing ==1)
{
sem_post(&mutex);
      sem_wait(&ComingToSurf);
}
 else{
    ReadyForSurfing--;
    numOfsurfing++;
    sem_post(&mutex);
  }
}




  surf(d);

  sem_wait(&mutex);
  numOfsurfing--;
  ReadyForLeaving++;
//leaving conditions
switch(ReadyForLeaving)

{  case '1':
  switch(numOfsurfing)
 {
   case '2' :printf("surfer %d is ready to leave\n", d->id);
    sem_post(&mutex);      
sem_wait(&GoingToLeave);
break;

case '1':printf("surfer %d is ready to leave\n", d->id);
    sem_post(&mutex);
    sem_wait(&GoingToLeave);
break;

default:printf("surfer %d is ready to leave\n", d->id);
    sem_post(&mutex);
    sem_wait(&GoingToLeave);
break;

  }   
break;
case 2: 
switch(numOfsurfing)

{

case 1:printf("surfer %d is ready to leave\n", d->id);
    sem_post(&mutex);
    sem_wait(&GoingToLeave);
break;

case 0:printf("surfer %d is ready to leave\n", d->id);
    sem_post(&GoingToLeave);
    ReadyForLeaving -= 2;
    sem_post(&mutex);
break;
}
break;
default :
 printf("surfer %d is ready to leave\n", d->id);
    ReadyForLeaving--;
    sem_post(&mutex);
    break;
} 
  leave(d);
}






/* Add code to main (DO NOT remove initialization code) */
int main() {
  printf("The Sharks are in the water.. Dont go single !!!!!!\n");
  int i=0,j=0;

  /* Initialize synchronization variables */
sem_init(&dusk, 0, 0) == -1;  
/* ... */
sem_init(&mutex, 1, 1) == -1;  // mutex is initialized to 1 - binary semaphore and second parameter = 1- so semaphore is global

sem_init(&ComingToSurf, 1, 0) == -1;
sem_init(&GoingToLeave, 1, 0) == -1;
  /* Initialize thread data structures */
  pthread_t t[NSURFERS];
  dataT **ds = malloc(sizeof(dataT) * NSURFERS);
  for (j=0; j<NSURFERS; j++) { ds[j] = malloc(sizeof(struct data)); ds[j]->id = j; }





  /* s1 and s2 start surfing */ //THIS HAS CHANGED
  /*surf(ds[0]);  //THIS HAS CHANGED
    surf(ds[1]);*/ //THIS HAS CHANGED

  /* Create monitor */
pthread_t mon;
  pthread_create(&mon, NULL, (void *)&monitor, (void *)ds);

  /* Create surfers */
  /* ... */




int s; //setting cpu core from where the code will run
	           cpu_set_t cpuset;
	           //pthread_t thread;

	          // thread = pthread_self();

	           s = pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);

	           /* Set affinity mask to include CPUs 0 to 7 */

	           CPU_ZERO(&cpuset);
 CPU_SET(1, &cpuset);



int rc;
  for (i = 0; i < NSURFERS; ++i)
  {

//Binding threads


rc= pthread_create(&t[i], NULL,(void *)&surfer,(void *)ds[i]);
 s = pthread_setaffinity_np(t[i], sizeof(cpu_set_t), &cpuset);
 
  }
 

  sem_wait(&dusk); // calling dusk
  for (i = 0; i < NSURFERS; ++i)
  { 
       if(pthread_kill(t[i],0)==0){
          printf("Its dusk !!!!! Surfer %d arrived too late, he has to go back\n",ds[i]->id);
         
     
   }
  }  

  /* Wait for surfers to finish */
  /* ... */
  for (i = 0; i < NSURFERS; ++i)
  {
       rc = pthread_join(t[i], NULL);

      }

  /* Wait for monitor to finish */
  pthread_join(mon, NULL);


sem_destroy(&mutex);
   sem_destroy(&GoingToLeave);
     sem_destroy(&dusk);
      sem_destroy(&monitor_mutex);

  return 0;
}

