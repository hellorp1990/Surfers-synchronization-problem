How to run the code.

in the command prompt--- type 'make' for compiling 
then  './surfers' to run